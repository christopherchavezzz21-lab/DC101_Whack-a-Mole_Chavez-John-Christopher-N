
const holes = document.querySelectorAll(".hole");
const moles = document.querySelectorAll(".mole");
let score = 0;
let timeLeft = 30;
let gameTimer;
let moleTimer;

function showMole() {
    holes.forEach(h => h.classList.remove("active"));
    const randomHole = holes[Math.floor(Math.random() * holes.length)];
    randomHole.classList.add("active");
}

moles.forEach(mole => {
    mole.addEventListener("click", () => {
        if (mole.parentNode.classList.contains("active")) {
            score++;
            document.getElementById("score").textContent = score;
            mole.parentNode.classList.remove("active");
        }
    });
});

function startGame() {
    score = 0;
    timeLeft = 30;
    document.getElementById("score").textContent = score;
    document.getElementById("time").textContent = timeLeft;

    moleTimer = setInterval(showMole, 1000);
    gameTimer = setInterval(() => {
        timeLeft--;
        document.getElementById("time").textContent = timeLeft;
        
        if (timeLeft <= 0) {
            endGame();
        }
    }, 1000);
}

function endGame() {
    clearInterval(moleTimer);
    clearInterval(gameTimer);
    holes.forEach(h => h.classList.remove("active"));
    alert("⏳ Time's up!\nYour final score: " + score);
}

document.getElementById("startBtn").addEventListener("click", startGame);